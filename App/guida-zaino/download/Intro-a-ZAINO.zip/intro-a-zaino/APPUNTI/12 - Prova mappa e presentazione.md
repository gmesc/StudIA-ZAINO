---
title: "12 - Prova mappa e presentazione"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Prova mappa e presentazione

La mappa riassume il percorso con nodi e sottonodi. La presentazione ha slide principali e approfondimenti sotto ciascun capitolo.

## Prova tu

1. Apri la mappa “Come si usa ZAINO”.
2. Espandi un ramo e apri il rimando alla pagina della miniguida.
3. Apri la presentazione “Come si usa ZAINO”.
4. Avvia Presenta e prova i capitoli e gli approfondimenti.
5. Torna alla guida e scegli una funzione nella sezione 4.

## Controlla

Hai completato il percorso base. Approfondisci Fonti, Appunti, Mappa, PRESENTA, LIM e Ripasso nella sezione 4.

[Apri la miniguida, pagina 12](pdf:0001#p=12)

![Schermata: Prova mappa e presentazione](fig:0001#p=12&i=1)

Apri Impostazioni, poi Zaino e “Apri la guida allo ZAINO”. La sezione 4 spiega ogni strumento.
