---
title: "06 - Sidebar: trova e organizza i materiali"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Sidebar: trova e organizza i materiali

La colonna laterale elenca i materiali dello zaino. Le sezioni compaiono quando contengono qualcosa. Un numero indica lo split che mostra quel materiale.

## Prova tu

1. Apri Fonti e scegli la miniguida PDF.
2. Apri Appunti e scegli “02 - Impostazioni”.
3. Trova il numero dello split accanto al materiale aperto.
4. Usa la matita della sezione per modificare o organizzare le voci disponibili.
5. Ridimensiona la colonna con il suo bordo.

## Controlla

Il nome identifica il materiale; il numero indica dove lo stai guardando.

[Apri la miniguida, pagina 6](pdf:0001#p=6)

![Schermata: Sidebar: trova e organizza i materiali](fig:0001#p=6&i=1)
