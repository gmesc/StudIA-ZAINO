---
title: "08 - Split: allarga, sposta e chiudi"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Split: allarga, sposta e chiudi

La testata contiene il numero dello split, il nome dello strumento e i comandi. Passa il puntatore su un’icona per leggerne il nome.

## Prova tu

1. Fai doppio clic sulla testata o sul numero dello split.
2. Ripeti il doppio clic per tornare al banco.
3. Trascina la testata su un altro split per scambiare i posti.
4. Apri la tendina dello strumento e prova Mappa.
5. Chiudi uno split con la sua X.
6. Riapri il materiale dalla sidebar.

## Controlla

Hai modificato la vista. Il materiale è ancora nello zaino.

[Apri la miniguida, pagina 8](pdf:0001#p=8)

![Schermata: Split: allarga, sposta e chiudi](fig:0001#p=8&i=1)
