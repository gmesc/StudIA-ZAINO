---
title: "01 - Inizia qui"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Apri lo zaino esempio

Lo zaino “Intro a ZAINO” è un laboratorio. Puoi modificare i suoi appunti, la mappa e la presentazione.

## Prova tu

1. Scarica lo zaino esempio dalla guida.
2. Estrai lo ZIP in una cartella del computer.
3. Apri Impostazioni, poi Zaino e leggi il percorso della cartella dati.
4. Chiudi ZAINO prima di copiare i file.
5. Apri la cartella dati e crea la sottocartella Zaini, se manca.
6. Copia solo la cartella intro-a-zaino dentro Zaini.
7. Riapri ZAINO e scegli “Intro a ZAINO” nel menu accanto al nome dell’app.
8. Apri l’appunto “01 - Inizia qui”.

## Controlla

Vedi gli appunti del percorso e la miniguida PDF nelle Fonti.

[Apri la miniguida, pagina 1](pdf:0001#p=1)

![Schermata: Apri lo zaino esempio](fig:0001#p=1&i=1)
