---
title: "11 - Leggi e mostra su un altro schermo"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Leggi e mostra su un altro schermo

Allargare uno split, usare lo schermo intero e aprire una finestra parallela sono tre azioni diverse.

## Prova tu

1. Apri l’appunto del percorso e passa alla vista renderizzata.
2. Usa il comando di lettura per ingrandire il testo.
3. Prova lo schermo intero e torna indietro con Esc.
4. Apri la finestra parallela dalla testata dello split.
5. Sposta la finestra sullo schermo esterno, se disponibile.
6. Chiudi la finestra parallela quando hai finito.

## Controlla

Sul computer mantieni gli strumenti; sullo schermo esterno mostri il contenuto.

[Apri la miniguida, pagina 11](pdf:0001#p=11)

![Schermata: Leggi e mostra su un altro schermo](fig:0001#p=11&i=1)
