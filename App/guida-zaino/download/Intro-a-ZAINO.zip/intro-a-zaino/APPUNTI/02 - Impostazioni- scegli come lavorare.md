---
title: "02 - Impostazioni: scegli come lavorare"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Impostazioni: scegli come lavorare

L’ingranaggio della topbar apre le Impostazioni. Le preferenze dell’AI sono facoltative; i file si possono usare subito.

## Prova tu

1. Apri l’ingranaggio nella topbar.
2. Apri Aspetto e scegli Atkinson Hyperlegible, se ti aiuta a leggere.
3. Apri Utente e osserva le preferenze del tutor.
4. Apri Zaino e trova la cartella dati e l’elenco degli zaini.
5. Chiudi le Impostazioni con la X.

## Controlla

Sai dove cambiare carattere, preferenze e cartella dei file.

[Apri la miniguida, pagina 2](pdf:0001#p=2)

![Schermata: Impostazioni: scegli come lavorare](fig:0001#p=2&i=1)
