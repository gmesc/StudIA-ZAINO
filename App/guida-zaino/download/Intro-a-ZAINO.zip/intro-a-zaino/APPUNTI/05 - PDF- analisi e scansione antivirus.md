---
title: "05 - PDF: analisi e scansione antivirus"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# PDF: analisi e scansione antivirus

qpdf verifica la struttura dei PDF e segnala anomalie. ClamAV cerca malware e virus conosciuti. I controlli lavorano sul computer, senza inviare i documenti online.

## Prova tu

1. Apri Impostazioni, poi Sicurezza.
2. Leggi lo stato di qpdf e ClamAV.
3. Per usare un motore, premi Installa e attendi il completamento.
4. Seleziona Attiva controllo per il motore installato.
5. Per ClamAV controlla le firme e usa Aggiorna firme, se necessario.
6. Consulta Ultimo controllo e leggi gli eventuali avvisi.

## Controlla

Sai quali controlli sono attivi e distingui un’analisi strutturale da una scansione antivirus.

[Apri la miniguida, pagina 5](pdf:0001#p=5)

![Schermata: PDF: analisi e scansione antivirus](fig:0001#p=5&i=1)
