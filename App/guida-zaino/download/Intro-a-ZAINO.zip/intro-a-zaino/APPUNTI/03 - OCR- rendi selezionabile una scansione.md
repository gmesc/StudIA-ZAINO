---
title: "03 - OCR: rendi selezionabile una scansione"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# OCR: rendi selezionabile una scansione

Un PDF scansionato contiene fotografie delle pagine. L’OCR riconosce le parole e aggiunge un testo selezionabile e ricercabile.

## Prova tu

1. Apri nelle Fonti un PDF scansionato o fotografato.
2. Prova a selezionare una frase: se manca il testo, usa l’OCR.
3. Nella barra premi “Riconosci il testo di questo documento fotografato”.
4. Attendi il riconoscimento e controlla le parole lette.
5. Per fermarti usa “Ferma il riconoscimento del testo”.
6. Riprova la selezione e cerca una parola con SEARCH.

## Controlla

Puoi selezionare e cercare le parole che prima erano soltanto in una fotografia.

[Apri la miniguida, pagina 3](pdf:0001#p=3)

![Schermata: OCR: rendi selezionabile una scansione](fig:0001#p=3&i=1)
