---
title: "07 - Banchi: prepara lo spazio"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# Banchi: prepara lo spazio

Il banco è la disposizione degli split. Uno split è un riquadro che ospita uno strumento. Cambiare banco non cancella i materiali.

## Prova tu

1. Apri l’icona BANCO nella topbar.
2. Scegli una disposizione con due split affiancati.
3. Nel primo split scegli Fonti.
4. Nel secondo scegli Appunti.
5. Sposta il divisore per dare più spazio alla lettura.
6. Prova il disegno di un banco personale dal menu BANCO.

## Controlla

Leggi il PDF e scrivi senza cambiare continuamente finestra.

[Apri la miniguida, pagina 7](pdf:0001#p=7)

![Schermata: Banchi: prepara lo spazio](fig:0001#p=7&i=1)
