---
title: "09 - SEARCH: ritrova quello che hai scritto"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# SEARCH: ritrova quello che hai scritto

La lente cerca per parole nei PDF leggibili, negli appunti, nei nodi delle mappe e nelle didascalie dello zaino aperto.

## Prova tu

1. Apri la lente nella topbar.
2. Scrivi “banco”.
3. Leggi il tipo e il contesto di ciascun risultato.
4. Premi un risultato per raggiungere il passaggio.
5. Chiudi la ricerca e riaprila con un’altra parola.

## Controlla

Trovi i testi senza ricordare in quale documento o appunto si trovano.

[Apri la miniguida, pagina 9](pdf:0001#p=9)

![Schermata: SEARCH: ritrova quello che hai scritto](fig:0001#p=9&i=1)
