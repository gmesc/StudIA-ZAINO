---
title: "04 - AI locale e tutor cloud"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# AI locale e tutor cloud

text aiuta la ricerca per significato sul computer. vision e video sono scaricabili, ma non attivano ancora la ricerca visiva.

## Prova tu

1. Apri Impostazioni, poi AI e AI locale.
2. Leggi dimensione e stato del componente text.
3. Premi text · Scarica solo se vuoi la ricerca per significato e hai una connessione.
4. Lascia AI cloud vuota se vuoi lavorare senza tutor.

## Controlla

Distingui il download del modello locale dalla chiave per il tutor remoto.

[Apri la miniguida, pagina 4](pdf:0001#p=4)

![Schermata: AI locale e tutor cloud](fig:0001#p=4&i=1)

[Tutorial API Infomaniak](https://insegnai.ch/articoliblog/guida-infomaniak.html)
