---
title: "10 - File: dove sono e perché"
creato: "2026-11-05T09:00:00.000Z"
modificato: "2026-11-05T09:00:00.000Z"
---

# File: dove sono e perché

La cartella dati scelta nelle Impostazioni contiene Zaini. Ogni zaino ha sottocartelle per fonti e materiali. I dati personali sono separati dal programma.

## Prova tu

1. Apri Impostazioni e la scheda Zaino.
2. Leggi il percorso della cartella dati.
3. Apri quella cartella con il gestore dei file del computer.
4. Trova Zaini e poi intro-a-zaino.
5. Osserva MATERIALI, APPUNTI, MAPPE, ALBUM e PRESENTAZIONI.
6. Chiudi ZAINO prima di fare una copia completa della cartella dati.

## Controlla

Sai fare un backup dei contenuti senza confonderli con il file dell’app.

[Apri la miniguida, pagina 10](pdf:0001#p=10)

![Schermata: File: dove sono e perché](fig:0001#p=10&i=1)
