---
id: "intro-a-zaino"
title: "Intro a ZAINO"
tipo: "zaino"
creato: "2026-11-05"
---

# Intro a ZAINO

I documenti stanno in `MATERIALI/PDF/`. Appunti, mappe e ritagli sono tuoi:
StudIA non ci scrive mai da sola.
